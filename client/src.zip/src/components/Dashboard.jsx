import React from 'react'
import Sidebar from './Sidebar'

export default function Dashboard() {
  return (
    <div>
    <h1>welcome , Plese Select Catogery</h1>
      <Sidebar/>
    </div>
  )
}
